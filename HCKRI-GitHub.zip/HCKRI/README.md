# HCKRI

多层次关联建模与知识增强的安全数据风险识别研究代码。

本代码实现多尺度残差CNN、Bi-LSTM、来源门控、Transformer、多阶段表征融合、原型风险库、原型对比损失及高置信伪标签训练。输入为CSV事件表，输出包含正常类和四个风险等级，并单独保存未知攻击判定标记。

## 发布范围

- 包含完整的数据读取、清洗编码、划分、窗口构建、训练、验证选模、测试评价流程。
- 提供TON-IoT、Edge-IIoTset、PSAD配置、Full与A-N消融统一入口、参数网格入口及自动化测试。
- 不包含原始数据、论文、服务器凭据、预训练权重、私有运行结果或第三方原始基线实现。
- 本仓库是研究实现，**不承诺自动复现论文旧表分数**。修正后的PSAD事件分组与旧实验不同；不得用旧结果覆盖新运行结果。
- 风险等级映射是配置中的研究规则，不是数据集官方风险分级，也不应作为被评估模型生成的参考标签。见[数据说明](docs/DATA.md)。

## 安装

建议创建独立Python环境。在仓库根目录执行：

```bash
python -m pip install -r requirements.txt
```

CUDA版PyTorch应按机器驱动和GPU架构选择对应构建，不要把系统CUDA工具链版本与PyTorch运行时版本混为一谈。`requirements.txt`只声明依赖，不伪装成跨平台锁文件；已记录的5090环境版本见[复现说明](docs/REPRODUCIBILITY.md)。

## 无数据快速自检

```bash
python -m unittest discover -s tests -v
python scripts/run_hckri.py --config configs/smoke.json --output outputs/smoke --allow-synthetic
```

自检使用小型合成数据、CPU和1轮训练，仅检查代码流程，**不是TON-IoT、Edge-IIoTset或PSAD实验结果**。输出目录必须不存在，程序不会覆盖旧实验。

## 真实数据实验

先按[数据说明](docs/DATA.md)准备CSV，默认不会自动下载，也不会在缺少数据时静默换成合成数据。

```bash
python scripts/run_hckri.py --config configs/ton_iot.json --output outputs/ton_full
python scripts/run_hckri.py --config configs/edge_iiot.json --output outputs/edge_full
python scripts/prepare_power_system_attack_dataset.py
python scripts/run_hckri.py --config configs/psad.json --output outputs/psad_full
```

`--device cpu`或`--device cuda`可覆盖配置。数据路径相对于仓库根目录解析；输出路径也相对于仓库根目录解析。

### Full及结构/学习消融

```bash
python scripts/run_hckri.py --config configs/ton_iot.json --output outputs/ton_ablation --variants Full A B C D E F G H I J K L M N
```

同次运行复用划分和标注掩码，每个变体重置同一随机种子。变体定义见[算法流程](docs/ALGORITHM.md)。这些是实际结构控制，不保证消融结果一定低于Full。

### 标注比例与伪标签阈值敏感性

```bash
python scripts/run_hckri.py --config configs/ton_iot.json --output outputs/ton_grid --fractions 0.1 0.3 0.5 --pseudo-thresholds 0.85 0.90 0.95
```

Edge-IIoTset和PSAD替换配置文件即可。各组合重新训练；不要按测试分数修改默认设置，也不要将不同数据划分下的历史F1混入曲线。

### 多源/多视图贡献实验

先用`prepare_ton_multiview.py`或`prepare_edge_multisource.py`生成视图，再使用对应配置：

```bash
python scripts/prepare_ton_multiview.py
python scripts/prepare_edge_multisource.py
python scripts/run_hckri.py --config configs/ton_iot_multiview_risk.json --output outputs/ton_views
```

在配置的`include_source_names`中选择来源子集，用新的输出目录分别运行。网络表拆分的协议视图不是新增采集的主机日志或遥测数据；事件对齐及分组方法须单独报告。旧版入口与配置仅供追溯，不能混用不同Full实现或训练预算。

## 输出

每个组合保存`config.json`、`checkpoint.pt`、`predictions.npz`、`history.json`、`result.json`、`confusion_matrix.json`及`per_class_counts.csv`。运行根目录保存`manifest.json`、`split_audit.json`、`labeled_masks.npz`和汇总`results.csv`。其中包含输入文件和代码SHA256、实际依赖版本、随机种子和划分计数，可据此追溯结果。

指标P/R/F1默认是风险类1-4的宏平均，正常类仍包含在五分类混淆矩阵中。旧代码`udr`字段实际对应UARC，即留出未知攻击被预测为任意风险的比例；这不是明确未知类召回率。统一入口同时导出`uarc`与`unknown_flag_recall`等字段。

## 目录

```text
configs/           三数据集推荐配置、合成自检配置、历史参考配置
src/power_risk/    编码、划分、网络、消融、指标和报告
scripts/          统一入口、训练实现、预处理及历史研究入口
tests/            结构一致性、数据隔离、编码及发布入口测试
docs/             算法流程、数据准备、复现边界和发布检查
SOURCE_MANIFEST.json  发布来源及逐文件校验值
```

## 上传GitHub

解压后将`HCKRI`目录作为仓库根目录上传，不要把原始工作区整体上传。首次公开前按[发布检查](docs/PUBLISH_CHECKLIST.md)确认作者、数据授权和代码许可证。此包未代作者选择开源许可证，也未自动创建或推送任何GitHub仓库。
